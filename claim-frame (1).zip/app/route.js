export const GET = () => {
  return new Response(`
    <!DOCTYPE html>
    <html>
    <head>
      <meta property="fc:frame" content="vNext" />
      <meta property="fc:frame:image" content="https://i.imgur.com/ZAEwB5W.png" />
      <meta property="fc:frame:button:1" content="Claim 5,000 Tokens" />
      <meta property="fc:frame:post_url" content="/claim" />
    </head>
    <body></body>
    </html>
  `, {
    headers: { "Content-Type": "text/html" }
  });
};
